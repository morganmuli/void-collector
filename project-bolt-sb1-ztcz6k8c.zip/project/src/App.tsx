import React, { useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Particles from './components/Particles';
import FeaturedCollections from './components/FeaturedCollections';
import UpcomingDrops from './components/UpcomingDrops';
import CollectorLore from './components/CollectorLore';
import MarketplacePreview from './components/MarketplacePreview';
import CommunityHub from './components/CommunityHub';
import Footer from './components/Footer';

function App() {
  useEffect(() => {
    // Update title
    document.title = 'VOID_COLLECTOR | Digital Artifacts from the Multiverse';
  }, []);

  return (
    <div className="relative">
      <Particles />
      <Header />
      <main>
        <Hero />
        <FeaturedCollections />
        <UpcomingDrops />
        <CollectorLore />
        <MarketplacePreview />
        <CommunityHub />
      </main>
      <Footer />
    </div>
  );
}

export default App;