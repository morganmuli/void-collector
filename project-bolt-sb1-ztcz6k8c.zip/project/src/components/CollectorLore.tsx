import { useState } from 'react';
import { ArrowRight, User } from 'lucide-react';

const loreChapters = [
  {
    id: 1,
    title: "Genesis",
    content: "In the year 2157, as the multiverse theory was confirmed, an entity known only as the Void_Collector emerged from the digital ether. Neither fully AI nor human, this mysterious curator began to harvest rare digital artifacts from across parallel realities, preserving them as NFTs for our dimension to experience..."
  },
  {
    id: 2,
    title: "Quantum Displacement",
    content: "The discovery of quantum displacement allowed the Void_Collector to traverse digital realms, harvesting fragments of code and digital art from timelines and universes that were collapsing or being erased. Each artifact contains echoes of these lost realities, capturing their essence before they faded forever..."
  },
  {
    id: 3,
    title: "The Protocol",
    content: "The Void Protocol was established to preserve the multiverse's digital heritage. Each artifact undergoes quantum stabilization, ensuring its authenticity and preventing degradation. The Collection grows with each passing cycle, as more dimensions are discovered and their digital footprints preserved..."
  },
  {
    id: 4,
    title: "Keepers of the Void",
    content: "Those who acquire artifacts become Keepers of the Void, entrusted with a fragment of alternative reality. This growing community forms a distributed archive of the multiverse, each member holding a piece of the cosmic digital puzzle that spans beyond our comprehension..."
  }
];

const testimonials = [
  {
    id: 1,
    name: "Cipher_Entity",
    avatar: "https://images.pexels.com/photos/2690323/pexels-photo-2690323.jpeg",
    text: "When I first acquired a Void artifact, I experienced dreams of the reality it came from for weeks. It's more than just digital art—it's a window to another existence.",
    rating: 5
  },
  {
    id: 2,
    name: "Neural_Ghost",
    avatar: "https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg",
    text: "My collection has grown to seven artifacts. Each seems to resonate with the others in ways I can't explain. Sometimes I see code patterns forming between them.",
    rating: 5
  },
  {
    id: 3,
    name: "Quantum_Whisper",
    avatar: "https://images.pexels.com/photos/5325840/pexels-photo-5325840.jpeg",
    text: "The Void_Collector's work transcends the typical NFT space. These aren't just artistic expressions—they're salvaged reality fragments.",
    rating: 4
  }
];

const CollectorLore = () => {
  const [activeChapter, setActiveChapter] = useState(1);
  const [expandedTestimonial, setExpandedTestimonial] = useState<number | null>(null);

  return (
    <section id="lore" className="py-20 relative">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Lore Chapters */}
          <div>
            <h2 className="text-3xl font-bold neon-text-green mb-2">The Collector's Lore</h2>
            <p className="font-mono text-gray-300 mb-8">Origins and purpose from beyond our dimension</p>
            
            <div className="space-y-4">
              {loreChapters.map((chapter) => (
                <div 
                  key={chapter.id}
                  className={`p-4 rounded-md cursor-pointer transition-all duration-300 ${
                    activeChapter === chapter.id 
                      ? 'neon-border bg-deepPurple/30' 
                      : 'bg-dark/50 hover:bg-deepPurple/20 border border-white/5'
                  }`}
                  onClick={() => setActiveChapter(chapter.id)}
                >
                  <h3 className={`text-lg font-semibold mb-2 ${
                    activeChapter === chapter.id ? 'neon-text-green' : 'text-white'
                  }`}>
                    {chapter.title}
                  </h3>
                  
                  <div className={`overflow-hidden transition-all duration-300 ${
                    activeChapter === chapter.id ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                  }`}>
                    <p className="font-mono text-gray-300 leading-relaxed text-sm mt-4">
                      {chapter.content}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8">
              <a href="#" className="flex items-center text-sm text-neonGreen hover:text-white transition-colors font-mono">
                <span>Read the complete chronicle</span>
                <ArrowRight size={16} className="ml-2" />
              </a>
            </div>
          </div>
          
          {/* Keeper Testimonials */}
          <div>
            <h2 className="text-3xl font-bold neon-text-blue mb-2">Keeper Testimonials</h2>
            <p className="font-mono text-gray-300 mb-8">Experiences from artifact collectors</p>
            
            <div className="space-y-6">
              {testimonials.map((testimonial) => (
                <div 
                  key={testimonial.id}
                  className="p-6 rounded-md bg-dark/50 border border-white/10 hover:neon-border transition-all duration-300 cursor-pointer"
                  onClick={() => setExpandedTestimonial(
                    expandedTestimonial === testimonial.id ? null : testimonial.id
                  )}
                >
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                      <img 
                        src={testimonial.avatar} 
                        alt={testimonial.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h3 className="text-md font-bold text-white">{testimonial.name}</h3>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <span 
                            key={i} 
                            className={`text-xs ${i < testimonial.rating ? 'text-neonBlue' : 'text-gray-600'}`}
                          >
                            ★
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <p className="font-mono text-gray-300 text-sm">
                    "{testimonial.text}"
                  </p>
                  
                  <div className={`mt-4 overflow-hidden transition-all duration-300 ${
                    expandedTestimonial === testimonial.id ? 'max-h-48 opacity-100' : 'max-h-0 opacity-0'
                  }`}>
                    <div className="pt-4 border-t border-white/10">
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-gray-400 font-mono">Artifact Collection: 7</p>
                        <p className="text-xs text-gray-400 font-mono">Member since 2157</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 bg-deepPurple/30 rounded-md p-6 border border-white/10">
              <h3 className="text-lg font-bold text-white mb-4">Share Your Experience</h3>
              <p className="text-sm text-gray-300 mb-4 font-mono">
                Acquired a Void artifact? Document your experience for the archive.
              </p>
              <button className="cyber-button group">
                <span className="relative z-10">Submit Testimony</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Section decorative elements */}
      <div className="absolute -bottom-40 left-0 w-full h-80 rounded-full bg-neonGreen/5 filter blur-[100px]"></div>
    </section>
  );
};

export default CollectorLore;