import { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  color: string;
  opacity: number;
  pulse: boolean;
}

const Particles: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animationFrameIdRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      if (canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initialize particles
    const particleCount = Math.min(100, window.innerWidth / 10);
    const particles: Particle[] = [];
    
    const neonColors = [
      'rgba(15, 244, 198, 0.7)', // neon blue
      'rgba(191, 0, 255, 0.6)',  // neon purple
      'rgba(57, 255, 20, 0.5)',  // neon green
    ];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5,
        speedX: Math.random() * 0.2 - 0.1,
        speedY: Math.random() * 0.2 - 0.1,
        color: neonColors[Math.floor(Math.random() * neonColors.length)],
        opacity: Math.random() * 0.5 + 0.2,
        pulse: Math.random() > 0.5,
      });
    }

    particlesRef.current = particles;

    // Add data stream lines
    const dataStreamLines: { startX: number; startY: number; length: number; speed: number; opacity: number }[] = [];
    
    for (let i = 0; i < 8; i++) {
      dataStreamLines.push({
        startX: Math.random() * canvas.width,
        startY: -100 - Math.random() * 500,
        length: 50 + Math.random() * 100,
        speed: 1 + Math.random() * 3,
        opacity: 0.1 + Math.random() * 0.4,
      });
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Update and draw particles
      particlesRef.current.forEach(particle => {
        particle.x += particle.speedX;
        particle.y += particle.speedY;
        
        // Wrap around edges
        if (particle.x < 0) particle.x = canvas.width;
        if (particle.x > canvas.width) particle.x = 0;
        if (particle.y < 0) particle.y = canvas.height;
        if (particle.y > canvas.height) particle.y = 0;
        
        // Pulsing effect
        if (particle.pulse) {
          particle.opacity = 0.2 + Math.sin(Date.now() * 0.001) * 0.3;
        }
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = particle.color.replace(/[\d\.]+\)$/, `${particle.opacity})`);
        ctx.fill();
      });
      
      // Update and draw data stream lines
      dataStreamLines.forEach(line => {
        line.startY += line.speed;
        
        if (line.startY > canvas.height) {
          line.startY = -100 - Math.random() * 200;
          line.startX = Math.random() * canvas.width;
        }
        
        const gradient = ctx.createLinearGradient(
          line.startX, line.startY, 
          line.startX, line.startY + line.length
        );
        
        const randomColor = Math.random();
        let color;
        
        if (randomColor < 0.33) {
          color = `rgba(15, 244, 198, ${line.opacity})`;
        } else if (randomColor < 0.66) {
          color = `rgba(191, 0, 255, ${line.opacity})`;
        } else {
          color = `rgba(57, 255, 20, ${line.opacity})`;
        }
        
        gradient.addColorStop(0, color);
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
        
        ctx.beginPath();
        ctx.moveTo(line.startX, line.startY);
        ctx.lineTo(line.startX, line.startY + line.length);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 1;
        ctx.stroke();
      });
      
      animationFrameIdRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationFrameIdRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="particles-container" />;
};

export default Particles;