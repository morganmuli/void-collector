import { Cuboid as Cube, Twitter, Instagram, Github, ExternalLink } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="relative pt-20 pb-10 border-t border-white/10 overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-1">
            <a href="#" className="flex items-center gap-2 group mb-4">
              <div className="relative">
                <Cube 
                  size={24} 
                  className="text-white group-hover:text-neonBlue transition-colors duration-300" 
                  strokeWidth={1.5}
                />
                <div className="absolute inset-0 bg-neonBlue/20 blur-md rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <span className="text-lg font-bold tracking-wider neon-text-blue">
                VOID_<span className="neon-text-purple">COLLECTOR</span>
              </span>
            </a>
            
            <p className="text-sm font-mono text-gray-400 mb-6">
              Curating digital artifacts from across the multiverse since 2157.
            </p>
            
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-neonBlue transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-neonPurple transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-neonGreen transition-colors">
                <Github size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Navigation</h3>
            <ul className="space-y-2 font-mono text-sm">
              <li>
                <a href="#collections" className="text-gray-400 hover:text-neonBlue transition-colors">Collections</a>
              </li>
              <li>
                <a href="#drops" className="text-gray-400 hover:text-neonPurple transition-colors">Drops</a>
              </li>
              <li>
                <a href="#lore" className="text-gray-400 hover:text-neonGreen transition-colors">Lore</a>
              </li>
              <li>
                <a href="#marketplace" className="text-gray-400 hover:text-neonBlue transition-colors">Marketplace</a>
              </li>
              <li>
                <a href="#community" className="text-gray-400 hover:text-neonPurple transition-colors">Community</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Resources</h3>
            <ul className="space-y-2 font-mono text-sm">
              <li>
                <a href="#" className="text-gray-400 hover:text-neonBlue transition-colors flex items-center">
                  Artifact Documentation
                  <ExternalLink size={12} className="ml-1" />
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-neonPurple transition-colors flex items-center">
                  Multiverse Theory
                  <ExternalLink size={12} className="ml-1" />
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-neonGreen transition-colors">Collector's Guide</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-neonBlue transition-colors">Authentication</a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-neonPurple transition-colors">FAQ</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Join The Void</h3>
            <p className="text-sm font-mono text-gray-400 mb-4">
              Subscribe to receive notifications about new artifact drops and dimensional discoveries.
            </p>
            
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-deepPurple/30 border border-white/10 rounded-l-md px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-neonBlue w-full"
              />
              <button className="bg-neonBlue/20 hover:bg-neonBlue/30 transition-colors border border-neonBlue text-white font-mono text-sm px-4 rounded-r-md">
                Join
              </button>
            </div>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center">
          <p className="text-xs font-mono text-gray-500 mb-4 md:mb-0">
            &copy; 2157-2025 VOID_COLLECTOR. All realities reserved.
          </p>
          
          <div className="flex space-x-6 font-mono text-xs">
            <a href="#" className="text-gray-500 hover:text-neonPurple transition-colors">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-neonPurple transition-colors">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-neonPurple transition-colors">Artifact License</a>
          </div>
        </div>
      </div>
      
      {/* Footer decoration */}
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-neonBlue/30 to-transparent"></div>
    </footer>
  );
};

export default Footer;