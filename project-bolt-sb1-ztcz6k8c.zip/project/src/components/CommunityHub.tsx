import { useState } from 'react';
import { Users, MessageSquare, Sparkles, Globe } from 'lucide-react';

interface CommunityPost {
  id: number;
  user: {
    name: string;
    avatar: string;
    level: number;
  };
  content: string;
  timestamp: string;
  likes: number;
  replies: number;
  hasImage: boolean;
  image?: string;
}

const communityPosts: CommunityPost[] = [
  {
    id: 1,
    user: {
      name: "Neural_Ghost",
      avatar: "https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg",
      level: 42
    },
    content: "Just acquired the Quantum Residue #037! The holographic effect is even more stunning in my digital vault. Has anyone else noticed the hidden patterns when viewed from certain angles?",
    timestamp: "2h ago",
    likes: 24,
    replies: 7,
    hasImage: true,
    image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg"
  },
  {
    id: 2,
    user: {
      name: "Cipher_Entity",
      avatar: "https://images.pexels.com/photos/2690323/pexels-photo-2690323.jpeg",
      level: 87
    },
    content: "Theory: The artifacts from Timeline 7B all contain fragments of code that, when combined, form a complete quantum algorithm. I've started analyzing the patterns. Anyone interested in collaborating?",
    timestamp: "5h ago",
    likes: 56,
    replies: 15,
    hasImage: false
  },
  {
    id: 3,
    user: {
      name: "Quantum_Whisper",
      avatar: "https://images.pexels.com/photos/5325840/pexels-photo-5325840.jpeg",
      level: 23
    },
    content: "New to the void community! Just got my first artifact yesterday - a Memory Fragment. The dreams have already started. Is this normal for new collectors?",
    timestamp: "12h ago",
    likes: 18,
    replies: 9,
    hasImage: false
  }
];

const communityStats = [
  {
    icon: <Users size={20} className="text-neonBlue" />,
    label: "Active Collectors",
    value: "3,721",
    color: "blue"
  },
  {
    icon: <Globe size={20} className="text-neonPurple" />,
    label: "Dimensions Accessed",
    value: "42",
    color: "purple"
  },
  {
    icon: <Sparkles size={20} className="text-neonGreen" />,
    label: "Artifacts Curated",
    value: "12.5K",
    color: "green"
  }
];

const CommunityHub = () => {
  const [activeTab, setActiveTab] = useState("feed");
  
  return (
    <section id="community" className="py-20 relative">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-3xl font-bold neon-text-purple mb-2">Community Hub</h2>
        <p className="font-mono text-gray-300 mb-12">Connect with fellow collectors across dimensions</p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Community Stats */}
          <div className="lg:col-span-1">
            <div className="bg-dark/70 backdrop-blur-sm rounded-lg p-6 border border-white/10 mb-8">
              <h3 className="text-lg font-bold text-white mb-4">Void Stats</h3>
              
              <div className="space-y-6">
                {communityStats.map((stat, index) => (
                  <div key={index} className="flex items-center">
                    <div className="mr-4 p-2 rounded-md bg-deepPurple/30">
                      {stat.icon}
                    </div>
                    <div>
                      <p className={`text-xl font-bold neon-text-${stat.color}`}>{stat.value}</p>
                      <p className="text-xs font-mono text-gray-400">{stat.label}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-dark/70 backdrop-blur-sm rounded-lg p-6 border border-white/10">
              <h3 className="text-lg font-bold text-white mb-4">Top Collectors</h3>
              
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex items-center">
                    <div className="mr-4 flex-shrink-0 relative">
                      <img 
                        src={`https://images.pexels.com/photos/${3000000 + i * 100}/pexels-photo-${3000000 + i * 100}.jpeg`}
                        alt={`Top collector ${i}`}
                        className="w-10 h-10 rounded-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg";
                        }}
                      />
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-neonBlue/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-[10px] font-bold">{i}</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">Collector_{i * 23}</p>
                      <p className="text-xs font-mono text-gray-400">{i * 12 + 20} artifacts</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <button className="mt-6 w-full text-sm text-center text-neonBlue hover:underline transition-colors font-mono">
                View Full Leaderboard
              </button>
            </div>
          </div>
          
          {/* Community Feed */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="bg-dark/70 backdrop-blur-sm rounded-lg p-1 border border-white/10 flex">
                {["feed", "discussions", "events", "guides"].map((tab) => (
                  <button
                    key={tab}
                    className={`flex-1 py-2 px-4 text-sm font-mono rounded transition-all ${
                      activeTab === tab 
                        ? 'bg-deepPurple/50 text-white' 
                        : 'text-gray-400 hover:text-white'
                    }`}
                    onClick={() => setActiveTab(tab)}
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="bg-dark/70 backdrop-blur-sm rounded-lg p-6 border border-white/10 mb-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full overflow-hidden">
                  <img 
                    src="https://images.pexels.com/photos/1559486/pexels-photo-1559486.jpeg" 
                    alt="Your avatar" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow">
                  <textarea 
                    className="w-full bg-deepPurple/20 border border-white/10 rounded-md p-3 text-white font-mono resize-none text-sm focus:outline-none focus:neon-border h-20"
                    placeholder="Share your thoughts with fellow collectors..."
                  ></textarea>
                  <div className="flex justify-between items-center mt-3">
                    <div className="flex space-x-2">
                      <button className="text-xs text-gray-400 hover:text-neonBlue transition-colors font-mono px-2 py-1 rounded border border-white/10">
                        Upload
                      </button>
                      <button className="text-xs text-gray-400 hover:text-neonPurple transition-colors font-mono px-2 py-1 rounded border border-white/10">
                        Link Artifact
                      </button>
                    </div>
                    <button className="cyber-button group text-sm py-1 px-4">
                      <span className="relative z-10">Post</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-6">
              {communityPosts.map((post) => (
                <div key={post.id} className="bg-dark/70 backdrop-blur-sm rounded-lg border border-white/10 overflow-hidden">
                  <div className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                        <img 
                          src={post.user.avatar} 
                          alt={post.user.name} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="flex items-center">
                          <h4 className="text-sm font-bold text-white mr-2">{post.user.name}</h4>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-neonPurple/20 text-neonPurple">
                            Lvl {post.user.level}
                          </span>
                        </div>
                        <p className="text-[11px] font-mono text-gray-400">{post.timestamp}</p>
                      </div>
                    </div>
                    
                    <p className="text-sm font-mono text-gray-300 mb-4 leading-relaxed">
                      {post.content}
                    </p>
                    
                    {post.hasImage && post.image && (
                      <div className="mb-4 rounded-md overflow-hidden">
                        <img 
                          src={post.image} 
                          alt="Post attachment" 
                          className="w-full h-auto object-cover"
                        />
                      </div>
                    )}
                    
                    <div className="flex items-center text-xs text-gray-400 font-mono">
                      <button className="flex items-center mr-4 hover:text-neonBlue transition-colors">
                        <span className="mr-1">↑</span>
                        <span>{post.likes}</span>
                      </button>
                      <button className="flex items-center hover:text-neonPurple transition-colors">
                        <MessageSquare size={12} className="mr-1" />
                        <span>{post.replies}</span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="px-6 py-3 bg-deepPurple/20 border-t border-white/10 flex justify-between items-center">
                    <input 
                      type="text" 
                      placeholder="Add a reply..." 
                      className="bg-transparent border-none text-white font-mono text-xs focus:outline-none w-full"
                    />
                    <button className="text-xs text-neonBlue font-mono">
                      Reply
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 text-center">
              <button className="text-sm text-neonPurple hover:underline transition-colors font-mono">
                Load More Messages from the Void
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Section decorative elements */}
      <div className="absolute -bottom-40 right-0 w-full h-80 rounded-full bg-neonBlue/5 filter blur-[100px]"></div>
    </section>
  );
};

export default CommunityHub;