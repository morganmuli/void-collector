import { useState, useEffect } from 'react';
import { Cuboid as Cube, Menu, X, Bot } from 'lucide-react';

interface NavLink {
  title: string;
  path: string;
  color: 'blue' | 'purple' | 'green';
}

const navLinks: NavLink[] = [
  { title: 'Collections', path: '#collections', color: 'blue' },
  { title: 'Drops', path: '#drops', color: 'purple' },
  { title: 'Lore', path: '#lore', color: 'green' },
  { title: 'Marketplace', path: '#marketplace', color: 'blue' },
  { title: 'Community', path: '#community', color: 'purple' },
];

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-dark/90 backdrop-blur-md py-3' : 'py-5 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2 group">
            <div className="relative">
              <Cube 
                size={28} 
                className="text-white group-hover:text-neonBlue transition-colors duration-300" 
                strokeWidth={1.5}
              />
              <div className="absolute inset-0 bg-neonBlue/20 blur-md rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <span className="text-xl font-bold tracking-wider neon-text-blue">
              VOID_<span className="neon-text-purple">COLLECTOR</span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link, index) => (
              <a 
                key={index}
                href={link.path}
                className={`font-mono text-sm tracking-wide transition-all duration-300 hover:neon-text-${link.color}`}
              >
                {link.title}
              </a>
            ))}
            <button className="cyber-button group">
              <span className="relative z-10">Connect</span>
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white hover:text-neonPurple transition-colors" 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div 
        className={`md:hidden absolute w-full bg-deepPurple/90 backdrop-blur-lg transition-all duration-300 overflow-hidden ${
          isMenuOpen ? 'max-h-screen py-4' : 'max-h-0'
        }`}
      >
        <div className="container mx-auto px-4">
          <nav className="flex flex-col space-y-4">
            {navLinks.map((link, index) => (
              <a 
                key={index}
                href={link.path}
                className={`font-mono text-sm py-2 border-b border-white/10 neon-text-${link.color}`}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.title}
              </a>
            ))}
            <button 
              className="cyber-button mt-4 self-start"
              onClick={() => setIsMenuOpen(false)}
            >
              <span className="relative z-10">Connect</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;