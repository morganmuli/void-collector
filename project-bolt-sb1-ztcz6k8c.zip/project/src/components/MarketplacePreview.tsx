import { DollarSign, ExternalLink } from 'lucide-react';

interface MarketItem {
  id: number;
  name: string;
  image: string;
  price: string;
  creator: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  timeLeft: string;
}

const rarityColors = {
  common: 'text-gray-300',
  rare: 'text-neonBlue',
  epic: 'text-neonPurple',
  legendary: 'text-neonGreen'
};

const marketItems: MarketItem[] = [
  {
    id: 1,
    name: "Quantum Residue #037",
    image: "https://images.pexels.com/photos/3826678/pexels-photo-3826678.jpeg",
    price: "Ξ 0.45",
    creator: "VOID_COLLECTOR",
    rarity: 'rare',
    timeLeft: "5h 23m"
  },
  {
    id: 2,
    name: "Neural Whisper",
    image: "https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg",
    price: "Ξ 1.2",
    creator: "DataShaper",
    rarity: 'epic',
    timeLeft: "2h 12m"
  },
  {
    id: 3,
    name: "Time Fracture #89",
    image: "https://images.pexels.com/photos/6444367/pexels-photo-6444367.jpeg",
    price: "Ξ 0.8",
    creator: "Paradox_Prime",
    rarity: 'rare',
    timeLeft: "8h 45m"
  },
  {
    id: 4,
    name: "Ethereal Key",
    image: "https://images.pexels.com/photos/5603660/pexels-photo-5603660.jpeg",
    price: "Ξ 3.5",
    creator: "VOID_COLLECTOR",
    rarity: 'legendary',
    timeLeft: "1h 50m"
  },
  {
    id: 5,
    name: "Memory Fragment #42",
    image: "https://images.pexels.com/photos/4100130/pexels-photo-4100130.jpeg",
    price: "Ξ 0.2",
    creator: "Neural_Ghost",
    rarity: 'common',
    timeLeft: "12h 10m"
  },
  {
    id: 6,
    name: "Dimension Shard",
    image: "https://images.pexels.com/photos/5089151/pexels-photo-5089151.jpeg",
    price: "Ξ 1.8",
    creator: "Cipher_Entity",
    rarity: 'epic',
    timeLeft: "3h 25m"
  }
];

const MarketplacePreview = () => {
  return (
    <section id="marketplace" className="py-20 relative bg-deepPurple/20">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12">
          <div>
            <h2 className="text-3xl font-bold neon-text-blue mb-2">Marketplace</h2>
            <p className="font-mono text-gray-300">Current digital artifacts available for acquisition</p>
          </div>
          
          <div className="mt-4 md:mt-0">
            <button className="cyber-button group">
              <span className="relative z-10">View Full Marketplace</span>
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {marketItems.map((item) => (
            <div key={item.id} className="glitch-container h-full">
              <div className="holographic-card h-full group transform transition-all duration-500 hover:translate-y-[-5px]">
                <div className="aspect-square overflow-hidden relative">
                  <img 
                    src={item.image} 
                    alt={item.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/50 to-transparent"></div>
                  
                  <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-mono ${rarityColors[item.rarity]} bg-dark/70 backdrop-blur-sm`}>
                    {item.rarity.charAt(0).toUpperCase() + item.rarity.slice(1)}
                  </div>
                  
                  <div className="absolute top-4 right-4 bg-dark/70 backdrop-blur-sm px-3 py-1 rounded-full flex items-center">
                    <DollarSign size={12} className="mr-1 text-neonGreen" />
                    <p className="text-xs font-mono text-white">{item.price}</p>
                  </div>
                </div>
                
                <div className="p-5 relative z-10 border-t border-white/10">
                  <h3 className="text-lg font-bold text-white mb-1 truncate">
                    {item.name}
                  </h3>
                  
                  <p className="text-xs font-mono text-gray-400 mb-4">
                    By <span className="text-gray-300">{item.creator}</span>
                  </p>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-xs bg-neonPurple/20 text-neonPurple px-2 py-1 rounded-full font-mono">
                      {item.timeLeft} left
                    </span>
                    
                    <button className="text-xs text-white hover:text-neonBlue transition-colors flex items-center font-mono">
                      <span>Place bid</span>
                      <ExternalLink size={12} className="ml-1" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-gray-400 font-mono mb-6">
            <span className="text-neonPurple">138</span> artifacts available • <span className="text-neonBlue">24</span> active auctions • <span className="text-neonGreen">1.2K</span> collectors
          </p>
          
          <button className="cyber-button group">
            <span className="relative z-10">Connect Wallet to Access</span>
          </button>
        </div>
      </div>
      
      {/* Section decorative elements */}
      <div className="absolute -top-40 right-0 w-full h-80 rounded-full bg-neonPurple/5 filter blur-[100px]"></div>
    </section>
  );
};

export default MarketplacePreview;