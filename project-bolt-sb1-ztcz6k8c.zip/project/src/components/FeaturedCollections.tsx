import { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Collection {
  id: number;
  name: string;
  image: string;
  artist: string;
  itemCount: number;
  accentColor: 'blue' | 'purple' | 'green';
}

const collections: Collection[] = [
  {
    id: 1,
    name: "Quantum Remnants",
    image: "https://images.pexels.com/photos/6753682/pexels-photo-6753682.jpeg",
    artist: "VOID_COLLECTOR",
    itemCount: 42,
    accentColor: 'blue'
  },
  {
    id: 2,
    name: "Digital Echoes",
    image: "https://images.pexels.com/photos/5011647/pexels-photo-5011647.jpeg",
    artist: "Neural_Ghost",
    itemCount: 36,
    accentColor: 'purple'
  },
  {
    id: 3,
    name: "Forbidden Algorithms",
    image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg",
    artist: "Cipher_Entity",
    itemCount: 18,
    accentColor: 'green'
  },
  {
    id: 4,
    name: "Time Fractals",
    image: "https://images.pexels.com/photos/2693212/pexels-photo-2693212.png",
    artist: "Paradox_Prime",
    itemCount: 24,
    accentColor: 'blue'
  },
];

const FeaturedCollections = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isStart, setIsStart] = useState(true);
  const [isEnd, setIsEnd] = useState(false);

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollContainerRef.current) return;
    
    const container = scrollContainerRef.current;
    const scrollAmount = container.clientWidth * 0.75;
    
    if (direction === 'left') {
      container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    
    const container = scrollContainerRef.current;
    setIsStart(container.scrollLeft <= 10);
    setIsEnd(container.scrollLeft + container.clientWidth >= container.scrollWidth - 10);
  };

  return (
    <section id="collections" className="py-20 relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl font-bold neon-text-blue mb-2">Featured Collections</h2>
            <p className="font-mono text-gray-400">Rare artifacts curated from across the multiverse</p>
          </div>
          
          <div className="hidden md:flex space-x-2">
            <button 
              onClick={() => scroll('left')}
              disabled={isStart}
              className={`p-2 rounded-full ${isStart ? 'text-gray-600 cursor-not-allowed' : 'neon-border text-neonBlue hover:text-white'}`}
            >
              <ChevronLeft size={20} />
            </button>
            <button 
              onClick={() => scroll('right')}
              disabled={isEnd}
              className={`p-2 rounded-full ${isEnd ? 'text-gray-600 cursor-not-allowed' : 'neon-border text-neonBlue hover:text-white'}`}
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
        
        <div 
          className="overflow-x-auto hide-scrollbar" 
          ref={scrollContainerRef}
          onScroll={handleScroll}
        >
          <div className="flex space-x-6 pb-6 min-w-max">
            {collections.map((collection) => (
              <div 
                key={collection.id}
                className="w-[280px] md:w-[350px] shrink-0 glitch-container"
              >
                <div className="holographic-card group h-full transform transition-transform duration-500 hover:scale-[1.02]">
                  <div className="aspect-[4/5] overflow-hidden relative">
                    <img 
                      src={collection.image} 
                      alt={collection.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/60 to-transparent"></div>
                  </div>
                  
                  <div className="p-6 relative z-10 bg-gradient-to-b from-dark/90 to-deepPurple/90 backdrop-blur-sm">
                    <h3 className={`text-xl font-bold neon-text-${collection.accentColor} mb-1`}>
                      {collection.name}
                    </h3>
                    <p className="text-sm font-mono text-gray-300 mb-3">
                      By <span className="text-white">{collection.artist}</span>
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400 font-mono">
                        {collection.itemCount} artifacts
                      </span>
                      <button className={`text-sm text-neon${collection.accentColor === 'blue' ? 'Blue' : collection.accentColor === 'purple' ? 'Purple' : 'Green'} font-mono hover:underline`}>
                        View Collection
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Section decorative elements */}
      <div className="absolute -bottom-80 left-0 w-full h-96 rounded-full bg-neonPurple/5 filter blur-[100px]"></div>
    </section>
  );
};

export default FeaturedCollections;