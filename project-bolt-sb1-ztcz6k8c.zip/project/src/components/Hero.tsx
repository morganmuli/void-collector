import { Terminal, Sparkles } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-[100vh] w-full pt-24 pb-20 flex items-center overflow-hidden">
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="flex items-center">
              <Terminal className="text-neonPurple mr-2" size={20} />
              <p className="font-mono text-sm text-neonPurple/80">// Accessing digital void</p>
            </div>
            
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight">
              <span className="neon-text-blue">Digital artifacts</span> from 
              <br />across the <span className="neon-text-green">multiverse</span>
            </h1>
            
            <p className="font-mono text-lg text-gray-300 leading-relaxed">
              Enter the void to discover rare digital treasures curated from the deepest corners of the multiverse. Each artifact carries a fragment of forgotten realities.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button className="cyber-button group">
                <span className="relative z-10">explore collections</span>
              </button>
              <button className="cyber-button group">
                <span className="relative z-10">latest drops</span>
              </button>
            </div>
            
            <div className="grid grid-cols-3 gap-4 mt-12">
              <div className="border border-white/10 rounded-md p-4 bg-deepPurple/30 backdrop-blur-sm">
                <p className="text-2xl font-bold neon-text-purple mb-1">3.2k+</p>
                <p className="text-xs font-mono text-gray-400">Artifacts collected</p>
              </div>
              <div className="border border-white/10 rounded-md p-4 bg-deepPurple/30 backdrop-blur-sm">
                <p className="text-2xl font-bold neon-text-blue mb-1">42</p>
                <p className="text-xs font-mono text-gray-400">Realities explored</p>
              </div>
              <div className="border border-white/10 rounded-md p-4 bg-deepPurple/30 backdrop-blur-sm">
                <p className="text-2xl font-bold neon-text-green mb-1">87%</p>
                <p className="text-xs font-mono text-gray-400">Anomaly rating</p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="glitch-container holographic-card aspect-square max-w-[500px] mx-auto rounded-lg overflow-hidden animate-float">
              <div className="absolute inset-0 bg-deepPurple/30 backdrop-blur-md z-10"></div>
              <img 
                src="https://images.pexels.com/photos/13547414/pexels-photo-13547414.jpeg" 
                alt="Void Collector Featured Artifact" 
                className="w-full h-full object-cover opacity-80"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-dark to-transparent z-20">
                <div className="flex items-center mb-2">
                  <Sparkles className="text-neonBlue mr-2" size={16} />
                  <p className="text-xs font-mono text-neonBlue/80">FEATURED ARTIFACT</p>
                </div>
                <h3 className="text-xl font-bold text-white mb-1">Ethereal Memory Fragment #42</h3>
                <p className="text-sm font-mono text-gray-300">Current bid: <span className="text-neonGreen">Ξ 2.3</span></p>
              </div>
              <div className="absolute top-4 right-4 bg-neonPurple/20 backdrop-blur-md px-3 py-1 rounded-full z-20">
                <p className="text-xs font-mono">Tier: Legendary</p>
              </div>
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-10 -left-10 w-24 h-24 rounded-full bg-neonBlue/20 filter blur-xl animate-pulse-glow"></div>
            <div className="absolute -bottom-5 right-8 w-36 h-36 rounded-full bg-neonPurple/20 filter blur-xl animate-pulse-glow" style={{ animationDelay: '1s' }}></div>
          </div>
        </div>
      </div>
      
      {/* Hero section decorative elements */}
      <div className="absolute top-20 left-[10%] w-px h-[60%] bg-gradient-to-b from-neonGreen/0 via-neonGreen/20 to-neonGreen/0"></div>
      <div className="absolute top-[30%] right-[8%] w-px h-[40%] bg-gradient-to-b from-neonBlue/0 via-neonBlue/20 to-neonBlue/0"></div>
    </section>
  );
};

export default Hero;