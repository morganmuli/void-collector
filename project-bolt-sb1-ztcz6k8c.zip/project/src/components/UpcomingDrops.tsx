import { useEffect, useState } from 'react';
import { Clock, AlertCircle } from 'lucide-react';

interface Drop {
  id: number;
  name: string;
  image: string;
  releaseDate: Date;
  artist: string;
  edition: string;
  accentColor: 'blue' | 'purple' | 'green';
}

const drops: Drop[] = [
  {
    id: 1,
    name: "Chronos Shards",
    image: "https://images.pexels.com/photos/6498731/pexels-photo-6498731.jpeg",
    releaseDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
    artist: "VOID_COLLECTOR",
    edition: "Limited",
    accentColor: 'blue'
  },
  {
    id: 2,
    name: "Neural Imprints",
    image: "https://images.pexels.com/photos/5022847/pexels-photo-5022847.jpeg",
    releaseDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
    artist: "DataShaper",
    edition: "Genesis",
    accentColor: 'purple'
  },
  {
    id: 3,
    name: "Glitch Protocol",
    image: "https://images.pexels.com/photos/2506947/pexels-photo-2506947.jpeg",
    releaseDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
    artist: "System_Error",
    edition: "Rare",
    accentColor: 'green'
  }
];

const UpcomingDrops = () => {
  const [timeLeft, setTimeLeft] = useState<Record<number, {days: number, hours: number, minutes: number, seconds: number}>>(
    drops.reduce((acc, drop) => ({
      ...acc,
      [drop.id]: calculateTimeLeft(drop.releaseDate)
    }), {})
  );

  function calculateTimeLeft(date: Date) {
    const difference = date.getTime() - new Date().getTime();
    
    return {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((difference / 1000 / 60) % 60),
      seconds: Math.floor((difference / 1000) % 60)
    };
  }

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(
        drops.reduce((acc, drop) => ({
          ...acc,
          [drop.id]: calculateTimeLeft(drop.releaseDate)
        }), {})
      );
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  return (
    <section id="drops" className="py-20 relative bg-deepPurple/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold neon-text-purple mb-2">Upcoming Drops</h2>
          <p className="font-mono text-gray-300 max-w-2xl mx-auto">Be the first to own these limited-edition digital artifacts before they vanish into the void</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {drops.map((drop) => (
            <div key={drop.id} className="glitch-container">
              <div className="holographic-card h-full group">
                <div className="aspect-video overflow-hidden relative">
                  <img 
                    src={drop.image} 
                    alt={drop.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.05]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/50 to-transparent"></div>
                  
                  <div className="absolute top-4 right-4 bg-dark/50 backdrop-blur-sm px-3 py-1 rounded-full flex items-center">
                    <Clock size={14} className={`text-neon${drop.accentColor === 'blue' ? 'Blue' : drop.accentColor === 'purple' ? 'Purple' : 'Green'} mr-1`} />
                    <p className="text-xs font-mono text-white">Coming Soon</p>
                  </div>
                </div>
                
                <div className="p-6 relative z-10">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className={`text-xl font-bold neon-text-${drop.accentColor}`}>
                      {drop.name}
                    </h3>
                    <span className="text-xs px-2 py-1 bg-neonPurple/20 rounded-full text-white font-mono">
                      {drop.edition}
                    </span>
                  </div>
                  
                  <p className="text-sm font-mono text-gray-300 mb-6">
                    By <span className="text-white">{drop.artist}</span>
                  </p>
                  
                  <div className="bg-dark/70 backdrop-blur-md rounded-md p-4 mb-4">
                    <p className="text-xs text-gray-400 font-mono mb-2 flex items-center">
                      <AlertCircle size={12} className="mr-1" />
                      Dropping in:
                    </p>
                    <div className="grid grid-cols-4 gap-2 text-center">
                      <div className="flex flex-col">
                        <span className={`text-lg font-bold neon-text-${drop.accentColor}`}>
                          {formatNumber(timeLeft[drop.id]?.days || 0)}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">Days</span>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-lg font-bold neon-text-${drop.accentColor}`}>
                          {formatNumber(timeLeft[drop.id]?.hours || 0)}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">Hours</span>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-lg font-bold neon-text-${drop.accentColor}`}>
                          {formatNumber(timeLeft[drop.id]?.minutes || 0)}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">Mins</span>
                      </div>
                      <div className="flex flex-col">
                        <span className={`text-lg font-bold neon-text-${drop.accentColor}`}>
                          {formatNumber(timeLeft[drop.id]?.seconds || 0)}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">Secs</span>
                      </div>
                    </div>
                  </div>
                  
                  <button className="w-full cyber-button group">
                    <span className="relative z-10">Set Reminder</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Section decorative elements */}
      <div className="absolute -top-40 right-0 w-full h-80 rounded-full bg-neonBlue/5 filter blur-[100px]"></div>
    </section>
  );
};

export default UpcomingDrops;