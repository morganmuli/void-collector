/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Orbitron"', 'sans-serif'],
        mono: ['"Space Mono"', 'monospace'],
      },
      colors: {
        dark: 'rgb(var(--color-dark) / <alpha-value>)',
        deeper: 'rgb(var(--color-darker) / <alpha-value>)',
        deepPurple: 'rgb(var(--color-deep-purple) / <alpha-value>)',
        neonBlue: 'rgb(var(--color-neon-blue) / <alpha-value>)',
        neonPurple: 'rgb(var(--color-neon-purple) / <alpha-value>)',
        neonGreen: 'rgb(var(--color-neon-green) / <alpha-value>)',
        spaceGray: 'rgb(var(--color-space-gray) / <alpha-value>)',
      },
      animation: {
        'float': 'float 6s ease-in-out infinite',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'glitch': 'glitch 0.5s ease-in-out infinite alternate-reverse',
      },
      keyframes: {
        'float': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        'pulse-glow': {
          '0%, 100%': { opacity: 0.6 },
          '50%': { opacity: 1 },
        },
        'glitch': {
          '0%': { transform: 'translateX(-2px)' },
          '25%': { transform: 'translateX(0)' },
          '50%': { transform: 'translateX(2px)' },
          '75%': { transform: 'translateX(-1px)' },
          '100%': { transform: 'translateX(1px)' },
        },
      },
    },
  },
  plugins: [],
};